# AI WORK OS — ローカルCLI（Linux用・試験版）

既存の `ai-work-os` v0.3 Controllerを使う**追加ランチャー**。VPS・systemd・GitHub Actions・OpenAI/Anthropic APIキーは使わない。Claude Code CLIおよびCodex CLIの既存ログインを利用する。

このZIPは**GitHubへ未反映**。新規ファイル `aiwos-local.py` を信頼済み `ai-work-os` のルート（`controller/` と `scripts/` がある位置）に配置する。既存コードや設定を上書きしない。

## 対応環境と安全条件

- 現時点では**Linux専用**。既存Controllerは `/proc` とsudoによるOSユーザー分離に依存し、macOS/Windowsにはそのまま使えない。
- **初期設定では `publish=none`**、10ワーカー管理・モデル最大同時1枠。初期監視対象は `tasks/` の契約だけ（`examples/` を自動実行しない）。GitHubへの自動push・PRは無効。
- **OS分離の検証に失敗したら、AIは1回も起動しない**。`agent_user` を空にしたりsudoersを省略して無理に動かさない。
- AIに与える `aiwos-agent` アカウントにはClaude/Codexの認証情報が存在し、実行コードから読める可能性がある。現状ネットワーク隔離もない。**本番・機密リポジトリでの無人実行は推奨しない**。まずダミー案件限定で実証。
- GitHubの `main` は未保護と直近確認されているため、自動マージは行わず、Ruleset設定を別途行う。

## セットアップ（Ubuntu/Linux。既存のdeploy/isolation/を流用）

前提: `/opt/aiwos/code` に信頼済み（root所有）のAI WORK OS checkout、`/srv/aiwos/repo` に別のデータclone。Git、Python3、`jsonschema`、Claude Code、Codex CLIを用意。

1. `aiwos-local.py` を `/opt/aiwos/code/` にコピーし、管理者所有・agentから書込不可にする。既存の `deploy/isolation/setup.sh` が想定する `aiwos-ctl`、`aiwos-agent`、`aiwos-ws` のユーザー・sudoersを設定する。**PCに既存サービスがある場合はその設定を壊さない**。
2. `aiwos-ctl` から読み書きできるよう `/var/lib/aiwos/state` と `/var/lib/aiwos/workspaces` を準備し、`/srv/aiwos/repo` をgit cloneする。参照: `docs/controller.md` のOSユーザー分離の説明。
3. 設定ファイルを作る（rootの代わりに信頼済みctlユーザーで実行）：

```bash
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py \
  --config /var/lib/aiwos/state/controller-local.json init \
  --repo-dir /srv/aiwos/repo \
  --state-dir /var/lib/aiwos/state \
  --workspaces-dir /var/lib/aiwos/workspaces \
  --agent-user aiwos-agent --agent-group aiwos-ws
```

4. ログインはagentユーザーに限定（サブスクログイン、APIキー不要）：

```bash
sudo -u aiwos-agent -H claude auth login
sudo -u aiwos-agent -H codex login --device-auth
```

5. 起動・状況確認・停止（以後同じ `--config` を指定）：

```bash
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py --config /var/lib/aiwos/state/controller-local.json doctor
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py --config /var/lib/aiwos/state/controller-local.json start
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py --config /var/lib/aiwos/state/controller-local.json status
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py --config /var/lib/aiwos/state/controller-local.json stop
```

`sync` はクラウド上のタスク契約を取り込む操作（隔離確認が必須）。`review TASK` は**Controller停止中**に、データclone配下のタスク契約の`reviewer`を使って `scripts/aiwos.py run --role reviewer --execute` を起動する。独立レビュー結果を人間承認と誤認しない。

```bash
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py --config /var/lib/aiwos/state/controller-local.json sync
sudo -u aiwos-ctl -H python3 /opt/aiwos/code/aiwos-local.py --config /var/lib/aiwos/state/controller-local.json review examples/development/task.json
```

## 今回の検証範囲

- 配布CLIのPython構文、ローカルのPID照合・初期設定などの単体確認のみ。
- **実Ubuntu PCでのOS分離、Claude/Codex実ログイン、GitHub連携、10ワーカー実運転は未検証**。運用開始前に必ずダミータスクで段階的に確認する。

`aiwos-local.py` の隣に含まれる `aiwos` は簡易起動ラッパー。両ファイルをリポジトリルートへ置けば、同じ引数で `./aiwos --config ... start/status/stop/review` が使える。システム全体のPATHに置く必要はない。

## 制約

現在のv0.3 Controllerは**1つの設定につき1つのタスク契約リポジトリを監視**する。複数の別プロダクトのGitHubリポジトリを横断する本来の「AI WORK OS」運用はまだ別機能で、今回のCLI追加だけでは達成しない。ChatGPTの最終判定もCLIから無人起動しない。
