# WindowsパソコンでAI WORK OSを動かす（WSL2・Linux分離）

ユーザーのローカルPCは以前 **Windows** と伺っているため、Windows PowerShell用の `aiwos.ps1` を同梱した。**VPSは使わない**。既存v0.3は Linux `/proc`・sudo・POSIX signal に依存するため、Windowsネイティブで直接起動はできない。Windows内の **WSL2 Ubuntu** 上で動かす。

## 最初の1回

1. PowerShellで `wsl --list --verbose` を実行し、Ubuntuがあるか確認。なければ管理者権限のPowerShellで `wsl --install -d Ubuntu`。必要なPC再起動やLinuxユーザー初期設定はWindows/WSLの指示に従う。
2. WSL Ubuntu内に**trusted checkout**として `/opt/aiwos/code` を準備。git、Python3、python3-jsonschema、sudo、Claude Code CLI、Codex CLIをインストールし、リポジトリの `deploy/isolation/setup.sh` に従って `aiwos-ctl` / `aiwos-agent` / `aiwos-ws` とsudoersを設定する。**実行コードとsudoersは管理者所有**とし、agentは書き換えられないようにする。
3. `aiwos-local.py` と `aiwos` を `/opt/aiwos/code/` に入れ、所有者・実行権限を安全に設定。`/srv/aiwos/repo` に作業用の**別clone**を作る。データ保存先 `/var/lib/aiwos/state` と `/var/lib/aiwos/workspaces` には ctl user が書き込めるようにする。セットアップ例は `README.md` 参照。
4. PowerShellから初期化:

```powershell
.\aiwos.ps1 init --repo-dir /srv/aiwos/repo --state-dir /var/lib/aiwos/state --workspaces-dir /var/lib/aiwos/workspaces --agent-user aiwos-agent --agent-group aiwos-ws
```

5. WSL Ubuntuのagentユーザーで`claude auth login` / `codex login --device-auth`（APIキー不要）。WSLの認証はWindows側から自動継承されない。GitHubアクセスは別途trusted userに設定する。
6. PowerShellから:

```powershell
.\aiwos.ps1 doctor
.\aiwos.ps1 start
.\aiwos.ps1 status
.\aiwos.ps1 stop
# Controller停止中に限り、契約で指定されたreviewerを実行
.\aiwos.ps1 review examples/development/task.json
```

## 重要な制約

- **初期設定は `publish=none`**。自動GitHub pushやPR作成は動かさない。10ワーカー管理、モデルの同時実行上限は1。初期監視対象は `tasks/` 配下のみで、サンプル `examples/` は自動実行しない。
- `start` 前に隔離侵入テストを通し、失敗したらフェイルクローズ。Windows側の認証情報をWSL agentに共有しない。
- Windowsがスリープ・シャットダウンしたら常駐運転は継続しない。WSL2の停止・再起動の挙動は実PCで確認する。
- **WSL2上の実稼働試験は未実施**。`test_local_cli.py`の単体テスト4件はLinuxコンテナで成功。モデル接続、git push、長時間稼働は未検証。
- WSL2のCLIをモデルに任意実行させるとagentユーザーのモデルログイン情報は読み得る。機密データは扱わず、当面はダミー契約を使う。OSユーザー分離は同一ユーザー内の認証保護にはならない。
