#!/usr/bin/env python3
"""Local Linux launcher for the existing AI WORK OS controller.

Install this file in the repository root next to `controller/` and `scripts/`.
No GitHub Actions, API keys, VPS, or systemd. Untrusted agent execution is
REFUSED until the existing OS-user isolation probe passes.
"""
import argparse
import fcntl
import json
import os
import signal
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG_DEFAULT = Path(os.environ.get("AIWOS_CONFIG", "~/.config/aiwos/controller.json")).expanduser()


def die(msg, code=2):
    print(f"aiwos-local: {msg}", file=sys.stderr)
    return code


def ensure_linux():
    if not sys.platform.startswith("linux") or not Path("/proc").is_dir():
        raise RuntimeError("existing v0.3 controller needs Linux /proc; macOS/Windows are not yet supported")


def verified_layout():
    if not (ROOT / "controller" / "main.py").is_file() or not (ROOT / "scripts" / "aiwos.py").is_file():
        raise RuntimeError("place aiwos-local.py in the ai-work-os repository root")


def load_cfg(path):
    verified_layout()
    from controller.config import load
    return load(path)


def paths(cfg):
    state = Path(cfg["state_dir"])
    return state / "controller-local.json", state / "controller-local.log", state / "controller-local.lock"


@contextmanager
def single_operator(cfg):
    state = Path(cfg["state_dir"])
    state.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(state, 0o700)
    _, _, lockfile = paths(cfg)
    fd = os.open(str(lockfile), os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def process_start_ticks(pid):
    """Linux /proc start-time token prevents stale pidfile / PID reuse signals."""
    try:
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
    except (OSError, ValueError, IndexError):
        return None


def controller_pid(cfg):
    pidpath, _, _ = paths(cfg)
    try:
        record = json.loads(pidpath.read_text())
        pid = int(record["pid"])
        if not record.get("start_ticks") or record["start_ticks"] != process_start_ticks(pid):
            return None
        # A stale pid file MUST NOT signal a reused PID. Check actual cmdline.
        argv = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")
        argv = [a.decode(errors="replace") for a in argv if a]
        cfgarg = str(Path(record["config"]).resolve())
        expected = ["-m", "controller", "run", "--config", cfgarg]
        if len(argv) < 6 or not any(argv[i:i+5] == expected for i in range(len(argv)-4)):
            return None
        if cfgarg != str(Path(cfg["_config_path"]).resolve()):
            return None
        return pid
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError):
        return None


def boundary_check(cfg):
    """No silent same-user AI execution, even when publish=none."""
    ensure_linux()
    if not cfg.get("agent_user") or not cfg.get("agent_group"):
        raise RuntimeError("agent_user/agent_group absent: refusing unisolated model execution")
    if cfg["agent_user"] == os.environ.get("USER"):
        raise RuntimeError("agent_user must differ from the trusted controller user")
    from controller.main import export_isolation_env, prepare, refresh_isolation
    export_isolation_env(cfg)
    store = prepare(cfg)
    try:
        ok = refresh_isolation(cfg, store)
        if not ok:
            verdict, _ = store.get_meta("isolation")
            raise RuntimeError("OS isolation probe failed: " + str((verdict or {}).get("reason")))
    finally:
        store.db.close()


def run_controller(cfg, action, extra=()):
    return subprocess.run([sys.executable, "-m", "controller", action, "--config", cfg["_config_path"], *extra],
                          cwd=ROOT, check=False).returncode


def cmd_start(cfg):
    with single_operator(cfg):
        if controller_pid(cfg):
            print("Controller already running; use status")
            return 0
        boundary_check(cfg)
        if run_controller(cfg, "check-config") != 0:
            return die("invalid config")
        pidpath, logpath, _ = paths(cfg)
        logfd = os.open(str(logpath), os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
        try:
            with os.fdopen(logfd, "ab") as logfile:
                proc = subprocess.Popen([sys.executable, "-m", "controller", "run", "--config", cfg["_config_path"]],
                                        cwd=ROOT, stdout=logfile, stderr=subprocess.STDOUT, start_new_session=True)
            time.sleep(0.4)
            if proc.poll() is not None:
                return die(f"controller exited with {proc.returncode}; see {logpath}", 1)
            tmp = pidpath.with_suffix(".tmp")
            ticks = process_start_ticks(proc.pid)
            if not ticks:
                proc.terminate()
                return die("cannot verify controller PID birth-time", 1)
            tmp.write_text(json.dumps({"pid": proc.pid, "config": cfg["_config_path"], "start_ticks": ticks}) + "\n")
            os.chmod(tmp, 0o600)
            os.replace(tmp, pidpath)
            print(f"Controller started (PID {proc.pid}), workers={cfg['workers']}, models={cfg['model_concurrency']}")
            print(f"Log: {logpath}")
            return 0
        except Exception:
            if 'proc' in locals() and proc.poll() is None:
                proc.terminate()
            raise


def cmd_status(cfg, raw=False):
    pid = controller_pid(cfg)
    print(f"Local controller: {'RUNNING (PID '+str(pid)+')' if pid else 'STOPPED / UNKNOWN'}")
    dbpath = Path(cfg["state_dir"]) / "aiwos.db"
    if not dbpath.exists():
        print("No task database yet")
        return 0
    return run_controller(cfg, "status", ("--json",) if raw else ())


def cmd_stop(cfg):
    with single_operator(cfg):
        pidpath, _, _ = paths(cfg)
        pid = controller_pid(cfg)
        if pid is None:
            print("Controller not running; no process was signalled")
            return 0
        os.kill(pid, signal.SIGTERM)
        # Existing controller owns worker shutdown. Never SIGKILL on timeout.
        for _ in range(180):
            if controller_pid(cfg) is None:
                pidpath.unlink(missing_ok=True)
                print("Controller stopped")
                return 0
            time.sleep(1)
        return die("stop timed out; process left intact for inspection", 1)


def cmd_review(cfg, task):
    with single_operator(cfg):
        if controller_pid(cfg):
            return die("manual review disallowed while controller is running (avoid competing task writers)")
        boundary_check(cfg)
        source = (Path(cfg["repo_dir"]) / task).resolve() if not Path(task).is_absolute() else Path(task).resolve()
        repo = Path(cfg["repo_dir"]).resolve()
        if not source.is_relative_to(repo) or not source.is_file() or source.suffix != ".json":
            return die("task must be an existing JSON file below configured repo_dir")
        env = os.environ.copy()
        env.update(AIWOS_ROOT=str(repo), AIWOS_AGENT_USER=cfg["agent_user"],
                   AIWOS_AGENT_GROUP=cfg["agent_group"], AIWOS_AGENT_PYTHON=cfg["agent_python"])
        # Runner enforces assigned reviewer, immutable run evidence, and --execute.
        return subprocess.run([sys.executable, str(ROOT / "scripts" / "aiwos.py"), "run", str(source),
                               "--role", "reviewer", "--execute"], cwd=ROOT, env=env, check=False).returncode


def cmd_init(args):
    verified_layout()
    cfgpath = Path(args.config).expanduser().resolve()
    if cfgpath.exists():
        return die(f"config already exists (not overwriting): {cfgpath}")
    from controller.config import DEFAULTS
    cfg = {**DEFAULTS}
    # Explicitly use a separate data checkout. Never let the worker modify trusted code.
    repo = Path(args.repo_dir).expanduser().resolve()
    if not (repo / ".git").exists():
        return die("repo_dir must be a separate existing git clone; create it with git clone first")
    if repo == ROOT:
        return die("repo_dir must not be the trusted AI WORK OS code checkout")
    cfg.update(repo_dir=str(repo), state_dir=str(Path(args.state_dir).expanduser().resolve()),
               workspaces_dir=str(Path(args.workspaces_dir).expanduser().resolve()), code_dir=str(ROOT),
               agent_user=args.agent_user, agent_group=args.agent_group, workers=10, model_concurrency=1,
               publish="none", task_globs=["tasks/*.json", "tasks/*/*.json"],
               credential_files=[str(Path(p).expanduser().resolve()) for p in args.credential_file],
               github_repo=args.github_repo)
    cfgpath.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = cfgpath.with_name(cfgpath.name + ".tmp")
    try:
        with os.fdopen(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as f:
            json.dump(cfg, f, indent=2)
            f.write("\n")
        os.replace(tmp, cfgpath)
    finally:
        tmp.unlink(missing_ok=True)
    print(f"Config created: {cfgpath} (publish=none, models=1, workers=10)")
    print("Next: configure Linux OS users/sudoers, verify credentials inaccessible to agent, then run doctor/start")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(prog="aiwos-local", description="Secure local Linux launcher for AI WORK OS")
    parser.add_argument("--config", default=str(CONFIG_DEFAULT), help="controller configuration JSON")
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="create config for an existing separate git clone")
    init.add_argument("--repo-dir", required=True)
    init.add_argument("--state-dir", required=True)
    init.add_argument("--workspaces-dir", required=True)
    init.add_argument("--agent-user", required=True)
    init.add_argument("--agent-group", required=True)
    init.add_argument("--credential-file", action="append", default=[])
    init.add_argument("--github-repo", default="masube-arent/ai-work-os")
    sub.add_parser("doctor", help="inspect local binaries/auth, without running an AI")
    sub.add_parser("start", help="start existing controller in background; isolated agents only")
    st = sub.add_parser("status")
    st.add_argument("--json", action="store_true")
    sub.add_parser("stop")
    sub.add_parser("sync", help="fetch queue without starting workers (can publish if configured)")
    rv = sub.add_parser("review", help="run the task contract's assigned reviewer through trusted runner")
    rv.add_argument("task", help="task JSON path within the data repo")
    args = parser.parse_args(argv)
    try:
        ensure_linux()
        verified_layout()
        if args.command == "init":
            return cmd_init(args)
        if args.command == "doctor":
            print("Running local CLI diagnosis (this does not start a model)")
            result = subprocess.run(["bash", str(ROOT / "scripts" / "doctor.sh")], cwd=ROOT)
            cfgpath = Path(args.config).expanduser()
            if cfgpath.exists():
                cfg = load_cfg(cfgpath)
                print(f"Config: {cfgpath.resolve()}; isolation user={cfg.get('agent_user') or 'NONE'}; publish={cfg['publish']}")
            return result.returncode
        cfgpath = Path(args.config).expanduser().resolve()
        cfg = load_cfg(cfgpath)
        cfg["_config_path"] = str(cfgpath)
        if args.command == "start":
            return cmd_start(cfg)
        if args.command == "stop":
            return cmd_stop(cfg)
        if args.command == "status":
            return cmd_status(cfg, args.json)
        if args.command == "review":
            return cmd_review(cfg, args.task)
        if args.command == "sync":
            # Sync may invoke git and PR APIs, so require same isolation gate.
            boundary_check(cfg)
            return run_controller(cfg, "sync-once")
        return die("unknown command")
    except (OSError, ValueError, RuntimeError, ImportError, subprocess.SubprocessError) as e:
        return die(f"{type(e).__name__}: {e}", 1)


if __name__ == "__main__":
    sys.exit(main())
