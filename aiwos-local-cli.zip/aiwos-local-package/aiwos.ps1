# AI WORK OS local launcher on Windows (PowerShell + WSL2 Ubuntu).
# No VPS, no GitHub Actions. WSL2 is local to this Windows PC.
# The trusted Python engine runs as aiwos-ctl, models as separate aiwos-agent.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('init', 'doctor', 'start', 'status', 'stop', 'sync', 'review')]
    [string] $Command,
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]] $ExtraArguments,
    [string] $Distro = 'Ubuntu',
    [string] $LinuxCode = '/opt/aiwos/code',
    [string] $LinuxConfig = '/var/lib/aiwos/state/controller-local.json'
)

if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) {
    throw 'WSL2 is not installed. Install Ubuntu WSL first: wsl --install -d Ubuntu'
}

$available = & wsl.exe --list --quiet 2>&1
if ($LASTEXITCODE -ne 0) {
    throw 'Could not query WSL distributions. Check WSL2 installation.'
}

# Avoid shell command concatenation and Invoke-Expression. Pass arguments directly.
& wsl.exe -d $Distro -u aiwos-ctl -- python3 "$LinuxCode/aiwos-local.py" --config $LinuxConfig $Command @ExtraArguments
exit $LASTEXITCODE
