"""Mock-based smoke checks of the standalone launcher; no AI or network needed."""
import importlib.util
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase, main, mock

MODULE = Path(__file__).resolve().with_name('aiwos-local.py')
spec = importlib.util.spec_from_file_location('aiwos_local', MODULE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class LocalLauncherTests(TestCase):
    def test_pidfile_cannot_signal_unverified_pid(self):
        with TemporaryDirectory() as d:
            cfg = {'state_dir': d, '_config_path': str(Path(d) / 'config.json')}
            pidpath = mod.paths(cfg)[0]
            pidpath.write_text(json.dumps({'pid': os.getpid(), 'config': cfg['_config_path'], 'start_ticks': 'bogus'}))
            self.assertIsNone(mod.controller_pid(cfg))

    def test_boundary_missing_user_fails_closed(self):
        with self.assertRaisesRegex(RuntimeError, 'agent_user/agent_group absent'):
            mod.boundary_check({'agent_user': None, 'agent_group': None})

    def test_status_stopped_has_no_side_effect(self):
        with TemporaryDirectory() as d:
            cfg = {'state_dir': d, '_config_path': str(Path(d) / 'config.json')}
            self.assertEqual(mod.cmd_status(cfg), 0)
            self.assertFalse((Path(d) / 'aiwos.db').exists())

    def test_stop_never_kills_unverified_pid(self):
        with TemporaryDirectory() as d:
            cfg = {'state_dir': d, '_config_path': str(Path(d) / 'config.json')}
            (Path(d) / 'controller-local.json').write_text(json.dumps({'pid': os.getpid(), 'config': cfg['_config_path'], 'start_ticks': 'bad'}))
            with mock.patch.object(mod.os, 'kill', side_effect=AssertionError('must not kill')):
                self.assertEqual(mod.cmd_stop(cfg), 0)


if __name__ == '__main__':
    main()
